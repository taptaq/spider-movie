<template>
  <div>影院</div>
</template>

<script>
export default {
  name: "cinema",
};
</script>

<style></style>
