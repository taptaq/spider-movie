<template>
  <div>电影</div>
</template>

<script>
export default {
  name: "movie",
};
</script>

<style></style>
