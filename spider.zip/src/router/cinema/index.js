export default {
    path:'/cinema',
    component:()=>import('@/views/cinema'),  //按需加载cinema组件
}